import React, { Component } from 'react';

export default class App extends Component {
  render() {
    return (
      <div>React Redux ca marche</div>
    );
  }
}
