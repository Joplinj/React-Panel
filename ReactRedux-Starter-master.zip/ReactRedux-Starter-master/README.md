### ReactRedux-Starter ###

Pour installer le projet se placer dans le projet et lancer : 

```
> npm install
> npm start
```

